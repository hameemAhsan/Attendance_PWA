# Acceptance Checklist

Use this checklist after deployment.

## PWA and Deployment

- [ ] `index.html` is in repository root.
- [ ] `manifest.json` loads in browser.
- [ ] `service-worker.js` loads in browser.
- [ ] `assets/icon-192.png` loads in browser.
- [ ] `assets/icon-512.png` loads in browser.
- [ ] GitHub Pages deployment is green.
- [ ] App opens from live GitHub Pages link.
- [ ] App can be added to Android home screen where supported.
- [ ] App shell works offline after first load.

## Teacher Login

- [ ] Teacher can log in using default password `teacher123`.
- [ ] Teacher can change password in Settings.
- [ ] Teacher can log out.

## Course Setup

- [ ] Teacher can create course offering.
- [ ] Course offering includes department, year, section, course code, course name, session.
- [ ] Student view code is generated or can be manually entered.
- [ ] Course offering can be selected.
- [ ] Course offering can be deleted.

## Student Import

- [ ] Teacher can download CSV template.
- [ ] Teacher can upload CSV student list.
- [ ] Import preview works.
- [ ] Missing roll/name is detected.
- [ ] Duplicate roll numbers in uploaded CSV are detected.
- [ ] Confirm import saves students to selected course.

## Attendance Taking

- [ ] Teacher can select course.
- [ ] Teacher can select date.
- [ ] Teacher can use optional class number/slot.
- [ ] Student list appears.
- [ ] Teacher can mark P, AI, AR.
- [ ] Mark all present works.
- [ ] Reset to random absent works.
- [ ] Attendance saves.
- [ ] Existing attendance for same date/course/class can be loaded and edited.

## Attendance Sheet

- [ ] Full attendance sheet appears.
- [ ] Dates become columns.
- [ ] Rows show roll and name.
- [ ] Summary columns show total P, AI, AR, absent, percentage.

## Student View

- [ ] Student can enter course view code.
- [ ] Student sees full sheet.
- [ ] Student cannot edit.

## Exports

- [ ] Excel-compatible `.xls` export works.
- [ ] CSV export works.
- [ ] View-only student HTML export works.
- [ ] `attendance-data.json` export works.
- [ ] `student-viewer.html` export works.
- [ ] Full JSON backup export works.
- [ ] JSON backup import restores data.

## Option B

- [ ] Exported student HTML opens without needing the main app.
- [ ] Exported Excel-compatible file opens in Excel.

## Option C

- [ ] `student-viewer.html` and `attendance-data.json` are uploaded to the same GitHub Pages folder.
- [ ] Static viewer loads JSON.
- [ ] Student can enter course code and see sheet.
- [ ] Replacing `attendance-data.json` updates the static viewer after refresh.
